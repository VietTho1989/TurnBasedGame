#include <gtest/gtest.h>

#include "movegenerator.hpp"

namespace ricefish {

}

