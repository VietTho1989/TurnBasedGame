#pragma once

namespace ricefish::Depth {

constexpr int MAX_PLY = 256;
constexpr int MAX_DEPTH = 64;

}