#pragma once

#include "board.hpp"

namespace ricefish {

void play();

void self_play(Board&);

}
